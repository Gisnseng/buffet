# Read the data
restaurants=read.csv("data/restaurants.csv")
restaurants$buffet=factor(restaurants$buffet,levels=c("No flag","Flagged"))
restaurants$cuisine=factor(restaurants$cuisine)
restaurants$price_tier=factor(ifelse(is.na(restaurants$price),"Unknown",as.character(restaurants$price)))
restaurants$log_reviews=log1p(restaurants$review_count)

# Split the training and test data
set.seed(438)
train=sample(1:nrow(restaurants),floor(0.8*nrow(restaurants)))
train_data=restaurants[train,]
test_data=restaurants[-train,]

# Group the cities
cities=names(sort(table(train_data$city),decreasing=TRUE))[1:10]
train_data$city_group=factor(ifelse(train_data$city %in% cities,train_data$city,"Other"),levels=c(cities,"Other"))
test_data$city_group=factor(ifelse(test_data$city %in% cities,test_data$city,"Other"),levels=c(cities,"Other"))

# Create the linear regression model
lm.fit=lm(stars~buffet+cuisine+city_group+price_tier+log_reviews,data=train_data)
lm.pred=predict(lm.fit,newdata=test_data)
mean.pred=rep(mean(train_data$stars),nrow(test_data))

# Calculate rating prediction errors
mean.mae=mean(abs(mean.pred-test_data$stars))
lm.mae=mean(abs(lm.pred-test_data$stars))
lm.mse=mean((lm.pred-test_data$stars)^2)
rating_error=c(mean.mae,lm.mae)

# Create the logistic regression model
glm.fits=glm(is_open~buffet+cuisine+city_group+price_tier+stars+log_reviews,data=train_data,family=binomial)
glm.probs=predict(glm.fits,newdata=test_data,type="response")
glm.pred=ifelse(glm.probs>=0.5,1,0)
open.pred=rep(as.integer(mean(train_data$is_open)>=0.5),nrow(test_data))

# Calculate open-status prediction accuracy
open.accuracy=mean(open.pred==test_data$is_open)
glm.accuracy=mean(glm.pred==test_data$is_open)
closed.recall=mean(glm.pred[test_data$is_open==0]==0)
open_accuracy=c(open.accuracy,glm.accuracy)*100

# Plot restaurant ratings
restaurant_labels=c("Regular restaurants","Buffet restaurants")
par(mfrow=c(1,1),mar=c(6.1,4.1,4.1,2.1))
boxplot(stars~buffet,data=restaurants,names=restaurant_labels,
        main="Customer ratings: regular vs. buffet restaurants",
        xlab="Restaurant type",ylab="Yelp rating (stars)",ylim=c(1,5))
mtext("Regular = no buffet/AYCE label found; buffet includes all-you-can-eat.",
      side=1,line=4.3,cex=0.75)

# Plot the percentage of restaurants listed as open
open_rate=tapply(restaurants$is_open,restaurants$buffet,mean)*100
positions=barplot(open_rate,names.arg=restaurant_labels,
                  main="Restaurants listed as open",
                  xlab="Restaurant type",ylab="Restaurants listed as open (%)",ylim=c(0,100))
text(positions,open_rate,sprintf("%.1f%%",open_rate),pos=3)
mtext("Yelp listing status is a snapshot, not a forecast of future closure.",
      side=1,line=4.3,cex=0.75)

# Plot the model comparisons
par(mfrow=c(1,2))
positions=barplot(rating_error,
                  names.arg=c("Average rating\nfor every restaurant","Linear regression"),
                  main="Rating prediction error",
                  ylab="Average error (MAE, stars)",ylim=c(0,0.8))
text(positions,rating_error,sprintf("%.3f",rating_error),pos=3)
mtext("Lower error is better",side=3,line=0.4,cex=0.8)

positions=barplot(open_accuracy,
                  names.arg=c("Always predict\nopen","Logistic regression"),
                  main="Open-status prediction accuracy",
                  ylab="Correct predictions (%)",ylim=c(0,100))
text(positions,open_accuracy,sprintf("%.1f%%",open_accuracy),pos=3)
mtext("Higher accuracy is better",side=3,line=0.4,cex=0.8)
